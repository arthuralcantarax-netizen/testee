import { useEffect, useMemo } from 'react';
import { View, ScrollView, ActivityIndicator } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { router, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { useLetterProgress } from '@/hooks/use-letter-progress';
import { useQuizResults } from '@/hooks/use-quiz-results';
import { QuizHistoryChart } from '@/components/QuizHistoryChart';
import { createPainelAlunoStyles } from '@/styles/painel-aluno.styles';

function getLevelInfo(masteredCount: number, total: number) {
  if (masteredCount === 0) return { icon: 'help-circle-outline' as const, label: 'Nenhuma letra' };
  if (masteredCount <= 17) return { icon: 'sprout' as const, label: 'Iniciante' };
  if (masteredCount <= 34) return { icon: 'tree-outline' as const, label: 'Aprendendo' };
  if (masteredCount < total) return { icon: 'pine-tree' as const, label: 'Avançado' };
  return { icon: 'trophy' as const, label: 'Completo!' };
}

function getTtsMessage(masteredCount: number, total: number, attemptsCount: number): string {
  if (masteredCount === 0) {
    return 'Olá! Você ainda não dominou nenhuma letra. Vá em Aprenda Desenhando para começar.';
  }
  if (masteredCount === total) {
    return `Parabéns! Você completou o alfabeto! Todas as ${total} letras foram dominadas. Você fez ${attemptsCount} tentativas no total.`;
  }
  const level = getLevelInfo(masteredCount, total);
  return `Olá! Você está no nível ${level.label}. Já aprendeu ${masteredCount} de ${total} letras. Continue praticando!`;
}

export default function PainelAlunoScreen() {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createPainelAlunoStyles(colors), [colors]);
  const { progress, isLoading, getMasteredCount, isComplete, totalLetters } = useLetterProgress();
  const { accuracyRate, sessionCount, totalCorrect, totalQuestions } = useQuizResults();

  const masteredCount = getMasteredCount();
  const completed = isComplete();
  const totalAttempts = useMemo(() =>
    progress.reduce((sum, p) => sum + p.attempts, 0),
  [progress]);
  const levelInfo = getLevelInfo(masteredCount, totalLetters);
  const progressPercent = totalLetters > 0 ? (masteredCount / totalLetters) * 100 : 0;

  useEffect(() => {
    if (!isLoading) {
      const timeout = setTimeout(() => {
        Speech.stop();
        Speech.speak(getTtsMessage(masteredCount, totalLetters, totalAttempts), {
          language: 'pt-BR',
          pitch: 1.1,
        });
      }, 500);
      return () => {
        clearTimeout(timeout);
        Speech.stop();
      };
    }
  }, [isLoading, masteredCount, totalLetters, totalAttempts]);

  const uppercaseLetters = progress.filter(p => p.letter === p.letter.toUpperCase());
  const lowercaseLetters = progress.filter(p => p.letter !== p.letter.toUpperCase());

  if (isLoading) {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        </SafeAreaView>
      </>
    );
  }

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <View style={styles.header}>
            <IconButton icon="arrow-left" size={32} iconColor={colors.text} onPress={() => {
              Speech.stop();
              router.back();
            }} />
            <Text variant="headlineSmall" style={styles.headerTitle}>Painel do Aluno</Text>
          </View>

          <ScrollView contentContainerStyle={styles.scrollContent}>
            {completed && (
              <View style={styles.completionBanner}>
                <MaterialCommunityIcons name="trophy" size={32} color="#ffffff" />
                <Text variant="titleLarge" style={styles.completionText}>Alfabeto Completo!</Text>
              </View>
            )}

            <View style={styles.levelCard}>
              <MaterialCommunityIcons name={levelInfo.icon} size={80} color={colors.primary} />
              <Text variant="headlineMedium" style={[styles.levelTitle, { color: colors.primary }]}>
                {levelInfo.label}
              </Text>
            </View>

            <View style={styles.progressSection}>
              <View style={styles.progressRow}>
                <Text variant="titleMedium" style={styles.progressText}>
                  {masteredCount} de {totalLetters} letras
                </Text>
                <Text variant="titleMedium" style={[styles.progressText, { color: colors.success }]}>
                  {Math.round(progressPercent)}%
                </Text>
              </View>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: `${progressPercent}%` }]} />
              </View>
            </View>

            <View style={styles.statsRow}>
              <View style={styles.statCard}>
                <MaterialCommunityIcons name="pencil" size={28} color={colors.primary} />
                <View>
                  <Text variant="titleLarge" style={styles.statText}>{totalAttempts}</Text>
                  <Text variant="bodySmall" style={styles.statLabel}>Tentativas</Text>
                </View>
              </View>
              <View style={styles.statCard}>
                <MaterialCommunityIcons name="check-circle" size={28} color={colors.success} />
                <View>
                  <Text variant="titleLarge" style={styles.statText}>{masteredCount}</Text>
                  <Text variant="bodySmall" style={styles.statLabel}>Dominadas</Text>
                </View>
              </View>
            </View>

            <Text variant="titleMedium" style={styles.sectionTitle}>Maiúsculas</Text>
            <View style={styles.grid}>
              {uppercaseLetters.map((p) => (
                <View
                  key={p.letter}
                  style={[
                    styles.letterCard,
                    p.mastered === 1 && styles.letterCardMastered,
                  ]}
                >
                  <Text
                    style={[
                      styles.letterText,
                      p.mastered === 1 && { color: colors.success },
                    ]}
                  >
                    {p.letter}
                  </Text>
                  {p.mastered === 1 && (
                    <View style={styles.letterCheck}>
                      <MaterialCommunityIcons name="check-circle" size={14} color={colors.success} />
                    </View>
                  )}
                </View>
              ))}
            </View>

            <Text variant="titleMedium" style={styles.sectionTitle}>Minúsculas</Text>
            <View style={styles.grid}>
              {lowercaseLetters.map((p) => (
                <View
                  key={p.letter}
                  style={[
                    styles.letterCard,
                    p.mastered === 1 && styles.letterCardMastered,
                  ]}
                >
                  <Text
                    style={[
                      styles.letterText,
                      p.mastered === 1 && { color: colors.success },
                    ]}
                  >
                    {p.letter}
                  </Text>
                  {p.mastered === 1 && (
                    <View style={styles.letterCheck}>
                      <MaterialCommunityIcons name="check-circle" size={14} color={colors.success} />
                    </View>
                  )}
                </View>
              ))}
            </View>

            <View style={styles.quizSection}>
              <View style={styles.quizTitleRow}>
                <MaterialCommunityIcons name="ear-hearing" size={24} color={colors.primary} />
                <Text variant="titleMedium" style={styles.quizTitle}>Aprenda Escutando</Text>
              </View>

              {sessionCount === 0 ? (
                <View style={styles.quizEmptyState}>
                  <MaterialCommunityIcons name="play-circle-outline" size={64} color={colors.textTertiary} />
                  <Text variant="bodyLarge" style={styles.quizEmptyText}>
                    Nenhum quiz realizado ainda
                  </Text>
                </View>
              ) : (
                <View style={styles.quizCard}>
                  <View style={styles.quizChartWrapper}>
                    <QuizHistoryChart
                      accuracyRate={accuracyRate}
                      size={160}
                      strokeWidth={18}
                      colors={colors}
                    />
                  </View>
                  <View style={styles.quizStatsRow}>
                    <View style={styles.quizStat}>
                      <Text variant="titleLarge" style={styles.quizStatValue}>{totalCorrect}</Text>
                      <Text variant="bodySmall" style={styles.quizStatLabel}>Acertos</Text>
                    </View>
                    <View style={styles.quizStat}>
                      <Text variant="titleLarge" style={styles.quizStatValue}>{totalQuestions - totalCorrect}</Text>
                      <Text variant="bodySmall" style={styles.quizStatLabel}>Erros</Text>
                    </View>
                    <View style={styles.quizStat}>
                      <Text variant="titleLarge" style={styles.quizStatValue}>{sessionCount}</Text>
                      <Text variant="bodySmall" style={styles.quizStatLabel}>Quizzes</Text>
                    </View>
                  </View>
                </View>
              )}
            </View>
          </ScrollView>
        </View>
      </SafeAreaView>
    </>
  );
}

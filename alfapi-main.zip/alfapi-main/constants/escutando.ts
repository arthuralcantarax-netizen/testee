export const TOTAL_QUESTIONS = 20;
export const TOTAL_OPTIONS = 4;
export const FEEDBACK_DELAY = 1500;

const UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const LOWERCASE = 'abcdefghijklmnopqrstuvwxyz'.split('');
export const LETTER_POOL = [...UPPERCASE, ...LOWERCASE];

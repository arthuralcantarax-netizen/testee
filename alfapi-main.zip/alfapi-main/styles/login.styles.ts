import { StyleSheet } from 'react-native';
import { AppColors } from '@/constants/themes';

export function createLoginStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: 24,
      justifyContent: 'center',
    },
    logoContainer: {
      alignItems: 'center',
      marginBottom: 16,
    },
    logo: {
      width: 220,
      height: 220,
    },
    title: {
      textAlign: 'center',
      marginBottom: 32,
      color: colors.text,
    },
    input: {
      marginBottom: 16,
    },
    button: {
      marginTop: 8,
    },
  });
}

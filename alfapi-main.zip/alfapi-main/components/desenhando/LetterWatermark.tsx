import { Platform } from 'react-native';
import { Group, Text as SkiaText, matchFont } from '@shopify/react-native-skia';
import { CANVAS_SIZE, LETTER_FONT_SIZE, LETTER_OPACITY } from '@/constants/desenhando';

interface LetterWatermarkProps {
  letter: string;
}

export function LetterWatermark({ letter }: LetterWatermarkProps) {
  const font = matchFont({
    fontFamily: Platform.OS === 'ios' ? 'Helvetica' : 'sans-serif',
    fontSize: LETTER_FONT_SIZE,
    fontWeight: 'bold',
  });

  if (!font) return null;

  const textWidth = font.getTextWidth(letter);
  const startX = (CANVAS_SIZE - textWidth) / 2;
  const baseline = CANVAS_SIZE * 0.78;

  return (
    <Group opacity={LETTER_OPACITY}>
      <SkiaText
        x={startX}
        y={baseline}
        text={letter}
        font={font}
        color="#3366FF"
      />
    </Group>
  );
}
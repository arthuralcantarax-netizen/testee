import { StyleSheet } from 'react-native';
import { AppColors } from '@/constants/themes';

export function createAcessibilidadeStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingVertical: 8,
    },
    headerTitle: {
      fontWeight: '700',
      color: colors.text,
      marginLeft: 8,
    },
    list: {
      padding: 16,
    },
    themeCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 16,
      padding: 20,
      marginBottom: 16,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    },
    themeCardSelected: {
      borderWidth: 2,
      borderColor: colors.primary,
    },
    themePreview: {
      width: 48,
      height: 48,
      borderRadius: 12,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 16,
    },
    themeInfo: {
      flex: 1,
      marginLeft: 20,
    },
    themeName: {
      color: colors.text,
      fontWeight: '900',
    },
    themeSubtitle: {
      color: colors.textSecondary,
      marginTop: 2,
    },
    checkmark: {
      marginLeft: 8,
    },
  });
}

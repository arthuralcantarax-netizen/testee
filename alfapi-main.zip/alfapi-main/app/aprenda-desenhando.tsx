import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { router, Stack } from 'expo-router';
import { GestureHandlerRootView, GestureDetector, Gesture } from 'react-native-gesture-handler';
import { Canvas, Path, Fill, useCanvasRef } from '@shopify/react-native-skia';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { useLetterProgress } from '@/hooks/use-letter-progress';
import { Stroke } from '@/types';
import { STROKE_WIDTH, CANVAS_SIZE } from '@/constants/desenhando';
import { buildPathFromPoints, verifyDrawing } from '@/utils/drawing';
import { LetterWatermark } from '@/components/desenhando/LetterWatermark';
import { DrawingControls } from '@/components/desenhando/DrawingControls';
import { CompletionScreen } from '@/components/desenhando/CompletionScreen';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { createDesenhandoStyles } from '@/styles/desenhando.styles';

export default function AprendaDesenhandoScreen() {
  const { currentLetter, saveAttempt, getMasteredCount, isComplete, totalLetters, isLoading, resetProgress } = useLetterProgress();
  const { colors } = useAppTheme();
  const styles = useMemo(() => createDesenhandoStyles(colors), [colors]);
  const insets = useSafeAreaInsets();
  const canvasRef = useCanvasRef();

  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const [showResetDialog, setShowResetDialog] = useState(false);

  useEffect(() => {
    if (currentLetter) {
      const isUpperCase = currentLetter === currentLetter.toUpperCase();

      const timeout = setTimeout(() => {
        const caseText = isUpperCase ? 'maiúscula' : 'minúscula';
        Speech.speak(`Essa é a letra ${currentLetter} ${caseText}. Desenhe por cima com o dedo.`, { language: 'pt-BR', pitch: 1.1 });
      }, 500);

      return () => clearTimeout(timeout);
    }
  }, [currentLetter]);

  useEffect(() => {
    if (isComplete() && !currentLetter) {
      Speech.speak('Parabéns! Você completou o alfabeto!', { language: 'pt-BR', pitch: 1.1 });
    }
  }, [isComplete, currentLetter]);

  const handleClear = useCallback(() => {
    setStrokes([]);
    setCurrentPoints([]);
    setIsChecking(false);
  }, []);

  const handleCheck = useCallback(async () => {
    if (!currentLetter || isChecking) return;

    const result = verifyDrawing(strokes);

    if (result.isValid) {
      setIsChecking(true);
      handleClear();

      await saveAttempt(currentLetter, result.confidence);

      Speech.speak('Muito bem!', { language: 'pt-BR', pitch: 1.2 });

      setTimeout(() => {
        setIsChecking(false);
      }, 1200);
    } else {
      Speech.speak('Continue desenhando.', { language: 'pt-BR', pitch: 1.1 });
    }
  }, [currentLetter, strokes, saveAttempt, handleClear, isChecking]);

  const handleResetConfirm = useCallback(() => {
    setShowResetDialog(false);
    handleClear();
    Speech.stop();
    Speech.speak('Progresso resetado', { language: 'pt-BR', pitch: 1.2 });
    resetProgress();
  }, [handleClear, resetProgress]);

  const panGesture = Gesture.Pan()
    .runOnJS(true)
    .onStart((e) => {
      setCurrentPoints([{ x: e.x, y: e.y }]);
    })
    .onChange((e) => {
      setCurrentPoints((prev) => [...prev, { x: e.x, y: e.y }]);
    })
    .onEnd(() => {
      if (currentPoints.length > 1) {
        const newStroke: Stroke = {
          id: Date.now().toString(),
          points: currentPoints,
        };
        setStrokes((prev) => [...prev, newStroke]);

        setTimeout(() => {
          const result = verifyDrawing([...strokes, newStroke]);
          if (result.isValid && !isChecking) {
            handleCheck();
          }
        }, 100);
      }
      setCurrentPoints([]);
    })
    .minDistance(1);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (isComplete() && !currentLetter) {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <SafeAreaView style={styles.safeArea}>
          <CompletionScreen
            onBack={() => setTimeout(() => router.back(), 300)}
            onReset={() => {
              Speech.stop();
              resetProgress();
            }}
          />
        </SafeAreaView>
      </>
    );
  }

  if (!currentLetter) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const masteredCount = getMasteredCount();
  const isUpperCase = currentLetter === currentLetter.toUpperCase();

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <GestureHandlerRootView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
          <IconButton icon="arrow-left" size={32} iconColor={colors.text} onPress={() => router.back()} />
          <View style={styles.progressContainer}>
            <Text variant="titleLarge" style={{ color: colors.text }}>Letra {masteredCount + 1} de {totalLetters}</Text>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${(masteredCount / totalLetters) * 100}%` }]} />
            </View>
          </View>
          <IconButton icon="trash-can" size={32} iconColor={colors.text} onPress={() => {
            Speech.speak('Se deseja resetar o progresso aperte o botão Verde, se não aperte o botão vermelho', { language: 'pt-BR', pitch: 1.1 });
            setShowResetDialog(true);
          }} />
        </View>

        <View style={styles.letterContainer}>
          <Text variant="displayMedium" style={styles.letterText}>
            {currentLetter}
          </Text>
          <Text variant="titleMedium" style={styles.caseLabel}>
            {isUpperCase ? 'Maiúscula' : 'Minúscula'}
          </Text>
        </View>

        <View style={styles.canvasContainer}>
          <GestureDetector gesture={panGesture}>
            <Canvas ref={canvasRef} style={styles.canvas}>
              <Fill color={colors.canvasBackground} />
              <LetterWatermark letter={currentLetter} />

              {strokes.map((stroke) => {
                const pathData = buildPathFromPoints(stroke.points);
                if (pathData.length === 0) return null;
                return (
                  <Path
                    key={stroke.id}
                    path={pathData}
                    color="#333333"
                    style="stroke"
                    strokeWidth={STROKE_WIDTH}
                    strokeCap="round"
                    strokeJoin="round"
                  />
                );
              })}

              {currentPoints.length > 1 && (
                <Path
                  path={buildPathFromPoints(currentPoints)}
                  color="#333333"
                  style="stroke"
                  strokeWidth={STROKE_WIDTH}
                  strokeCap="round"
                  strokeJoin="round"
                />
              )}
            </Canvas>
          </GestureDetector>
        </View>

        <DrawingControls
          onClear={handleClear}
          onCheck={handleCheck}
          isChecking={isChecking}
        />

        <View style={styles.instructions}>
          <Text variant="bodyLarge" style={styles.instructionText}>
            Desenhe por cima da letra com o dedo
          </Text>
        </View>

        <ConfirmDialog
          visible={showResetDialog}
          icon="alert-circle"
          iconColor={colors.danger}
          title="Resetar Progresso"
          message="Todo o progresso do alfabeto será perdido."
          speechText="Se deseja resetar o progresso aperte o botão Verde, se não aperte o botão vermelho"
          onConfirm={handleResetConfirm}
          onDismiss={() => setShowResetDialog(false)}
        />
      </GestureHandlerRootView>
    </>
  );
}

import { StyleSheet } from 'react-native';
import { AppColors } from '@/constants/themes';

const LETTER_SIZE = 44;

export function createPainelAlunoStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingVertical: 4,
    },
    headerTitle: {
      fontWeight: '700',
      color: colors.text,
      marginLeft: 8,
    },
    scrollContent: {
      padding: 16,
      paddingBottom: 32,
    },
    levelCard: {
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 16,
      marginBottom: 16,
      backgroundColor: colors.surface,
      borderRadius: 20,
    },
    levelTitle: {
      fontWeight: '700',
      color: colors.text,
    },
    progressSection: {
      marginBottom: 16,
    },
    progressRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 8,
    },
    progressText: {
      fontWeight: '600',
      color: colors.text,
    },
    progressBarBg: {
      height: 20,
      backgroundColor: colors.progressBackground,
      borderRadius: 10,
      overflow: 'hidden',
    },
    progressBarFill: {
      height: '100%',
      backgroundColor: colors.success,
      borderRadius: 10,
    },
    statsRow: {
      flexDirection: 'row',
      gap: 12,
      marginBottom: 16,
    },
    statCard: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      padding: 16,
      backgroundColor: colors.surface,
      borderRadius: 16,
    },
    statText: {
      fontWeight: '600',
      color: colors.text,
    },
    statLabel: {
      color: colors.textSecondary,
    },
    sectionTitle: {
      fontWeight: '700',
      color: colors.text,
      marginBottom: 8,
    },
    grid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 6,
      marginBottom: 16,
    },
    letterCard: {
      width: LETTER_SIZE,
      height: LETTER_SIZE,
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
    },
    letterCardMastered: {
      backgroundColor: colors.successLight,
      borderColor: colors.success,
    },
    letterText: {
      fontWeight: '700',
      color: colors.text,
      fontSize: 18,
    },
    letterCheck: {
      position: 'absolute',
      top: -4,
      right: -4,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    completionBanner: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      padding: 20,
      backgroundColor: colors.success,
      borderRadius: 20,
      marginBottom: 16,
    },
    completionText: {
      fontWeight: '700',
      color: '#ffffff',
    },
    quizSection: {
      marginTop: 24,
      marginBottom: 16,
      paddingTop: 20,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    quizTitleRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginBottom: 16,
    },
    quizTitle: {
      fontWeight: '700',
      color: colors.text,
    },
    quizCard: {
      backgroundColor: colors.surface,
      borderRadius: 20,
      padding: 20,
      alignItems: 'center',
    },
    quizChartWrapper: {
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 16,
    },
    quizStatsRow: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      width: '100%',
      marginTop: 12,
    },
    quizStat: {
      alignItems: 'center',
    },
    quizStatValue: {
      fontWeight: '700',
      color: colors.text,
    },
    quizStatLabel: {
      color: colors.textSecondary,
    },
    quizEmptyState: {
      alignItems: 'center',
      paddingVertical: 24,
    },
    quizEmptyText: {
      color: colors.textSecondary,
      marginTop: 8,
      textAlign: 'center',
    },
  });
}

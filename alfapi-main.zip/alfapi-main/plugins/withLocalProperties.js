const fs = require("fs");
const path = require("path");
const os = require("os");
const { withDangerousMod } = require("expo/config-plugins");

function getAndroidSdkPath() {
  if (process.env.ANDROID_HOME) return process.env.ANDROID_HOME;
  if (process.env.ANDROID_SDK_ROOT) return process.env.ANDROID_SDK_ROOT;
  const platform = process.platform;
  if (platform === "win32") {
    return "C:\\Users\\PIT-Dev\\AppData\\Local\\Android\\Sdk";
  }
  return path.join(os.homedir(), "Android", "Sdk");
}

function withLocalProperties(config) {
  return withDangerousMod(config, [
    "android",
    async (config) => {
      const sdkPath = getAndroidSdkPath();
      const filePath = path.join(
        config.modRequest.platformProjectRoot,
        "local.properties",
      );
      fs.writeFileSync(filePath, `sdk.dir=${sdkPath.replace(/\\/g, "/")}\n`);
      return config;
    },
  ]);
}

module.exports = withLocalProperties;

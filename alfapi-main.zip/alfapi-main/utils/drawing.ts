import { Point, Stroke } from '@/types';
import {
  CANVAS_SIZE,
  COVERAGE_THRESHOLD,
  MIN_POINTS_VALID,
} from '@/constants/desenhando';

export function buildPathFromPoints(points: Point[]): string {
  if (points.length < 2) return '';
  let pathData = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const midX = (prev.x + curr.x) / 2;
    const midY = (prev.y + curr.y) / 2;
    pathData += ` Q ${prev.x} ${prev.y} ${midX} ${midY}`;
  }
  const last = points[points.length - 1];
  pathData += ` L ${last.x} ${last.y}`;
  return pathData;
}

function getLetterBounds(): { left: number; right: number; top: number; bottom: number } {
  const centerX = CANVAS_SIZE / 2;
  const baseline = CANVAS_SIZE * 0.78;
  const letterWidth = CANVAS_SIZE * 0.5;
  const letterHeight = CANVAS_SIZE * 0.55;

  return {
    left: centerX - letterWidth / 2,
    right: centerX + letterWidth / 2,
    top: baseline - letterHeight,
    bottom: baseline,
  };
}

function pointsInsideLetter(allPoints: Point[], bounds: { left: number; right: number; top: number; bottom: number }): number {
  let count = 0;
  for (const point of allPoints) {
    if (
      point.x >= bounds.left &&
      point.x <= bounds.right &&
      point.y >= bounds.top &&
      point.y <= bounds.bottom
    ) {
      count++;
    }
  }
  return count;
}

function calculateLetterGridCoverage(
  strokes: Stroke[],
  bounds: { left: number; right: number; top: number; bottom: number }
): number {
  const gridSize = 6;
  const cellW = (bounds.right - bounds.left) / gridSize;
  const cellH = (bounds.bottom - bounds.top) / gridSize;

  const filledCells = new Set<string>();
  const allPoints = strokes.flatMap(s => s.points);

  for (const point of allPoints) {
    if (
      point.x >= bounds.left && point.x <= bounds.right &&
      point.y >= bounds.top && point.y <= bounds.bottom
    ) {
      const col = Math.min(Math.floor((point.x - bounds.left) / cellW), gridSize - 1);
      const row = Math.min(Math.floor((point.y - bounds.top) / cellH), gridSize - 1);
      filledCells.add(`${row}-${col}`);
    }
  }

  const totalCells = gridSize * gridSize;
  return filledCells.size / totalCells;
}

export function verifyDrawing(strokes: Stroke[]): { isValid: boolean; confidence: number } {
  const allPoints = strokes.flatMap(s => s.points);

  if (allPoints.length < MIN_POINTS_VALID) {
    return { isValid: false, confidence: 0 };
  }

  const bounds = getLetterBounds();

  const pointsInBounds = pointsInsideLetter(allPoints, bounds);
  const accuracyRatio = pointsInBounds / allPoints.length;

  if (accuracyRatio < 0.5) {
    return { isValid: false, confidence: accuracyRatio };
  }

  const gridCoverage = calculateLetterGridCoverage(strokes, bounds);
  const confidence = gridCoverage;

  const isValid = confidence >= COVERAGE_THRESHOLD;

  return { isValid, confidence };
}
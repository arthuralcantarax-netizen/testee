import { Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppTheme } from '@/contexts/ThemeContext';
import { createMenuStyles } from '@/styles/menu.styles';

interface MenuButtonProps {
  title: string;
  icon: string;
  onPress: () => void;
}

export function MenuButton({ title, icon, onPress }: MenuButtonProps) {
  const { colors } = useAppTheme();
  const styles = createMenuStyles(colors);

  return (
    <Pressable style={styles.button} onPress={onPress}>
      <MaterialCommunityIcons name={icon as any} size={80} color={colors.iconColor} />
      <Text variant="headlineSmall" style={styles.buttonText}>{title}</Text>
    </Pressable>
  );
}

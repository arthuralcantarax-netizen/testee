import { Modal, View, Pressable, Dimensions } from 'react-native';
import { Card } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Document } from '@/types';
import { useAppTheme } from '@/contexts/ThemeContext';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface DocumentViewerModalProps {
  document: Document | null;
  uri: string;
  onClose: () => void;
  onDelete: (doc: Document) => void;
}

export function DocumentViewerModal({ document, uri, onClose, onDelete }: DocumentViewerModalProps) {
  const { colors } = useAppTheme();

  return (
    <Modal
      visible={document !== null}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={{
        flex: 1,
        backgroundColor: colors.overlay,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
        <Pressable style={{
          position: 'absolute',
          top: 50,
          right: 20,
          zIndex: 10,
          padding: 8,
        }} onPress={onClose}>
          <MaterialCommunityIcons name="close-circle" size={40} color="#ffffff" />
        </Pressable>
        {document && (
          <>
            <Card.Cover
              source={{ uri }}
              style={{
                width: SCREEN_WIDTH,
                height: SCREEN_HEIGHT * 0.7,
              }}
              resizeMode="contain"
            />
            <Pressable
              style={{
                position: 'absolute',
                bottom: 60,
                padding: 12,
                borderRadius: 30,
              }}
              onPress={() => onDelete(document)}
            >
              <MaterialCommunityIcons name="delete" size={32} color={colors.danger} />
            </Pressable>
          </>
        )}
      </View>
    </Modal>
  );
}

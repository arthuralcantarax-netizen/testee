import { QuizQuestion } from '@/types';
import { TOTAL_QUESTIONS, TOTAL_OPTIONS, LETTER_POOL } from '@/constants/escutando';

function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function generateQuiz(): QuizQuestion[] {
  const selected = shuffle(LETTER_POOL).slice(0, TOTAL_QUESTIONS);

  return selected.map((correctLetter) => {
    const distractors = LETTER_POOL
      .filter((l) => l !== correctLetter)
      .sort(() => Math.random() - 0.5)
      .slice(0, TOTAL_OPTIONS - 1);

    const options = shuffle([correctLetter, ...distractors]);

    return { correctLetter, options };
  });
}

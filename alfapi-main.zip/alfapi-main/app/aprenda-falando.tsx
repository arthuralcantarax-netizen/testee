import { useState, useEffect, useRef, useMemo } from 'react';
import { View, Pressable } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { router, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { CircularProgress } from '@/components/CircularProgress';
import { useQuizResults } from '@/hooks/use-quiz-results';
import { QuizQuestion } from '@/types';
import { TOTAL_QUESTIONS, FEEDBACK_DELAY } from '@/constants/escutando';
import { generateQuiz } from '@/utils/quiz';
import { createFalandoStyles } from '@/styles/falando.styles';

function getResultMessage(score: number): string {
  if (score >= 15) return 'Muito bem! Você está ótimo!';
  if (score >= 10) return 'Você está no caminho!';
  return 'Você precisa se esforçar mais';
}

export default function AprendaEscutandoScreen() {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createFalandoStyles(colors), [colors]);
  const { saveQuizResult } = useQuizResults();
  const quizRef = useRef<QuizQuestion[] | null>(null);

  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [feedbackType, setFeedbackType] = useState<'correct' | 'wrong' | null>(null);
  const [isFinished, setIsFinished] = useState(false);
  const [spokenIndex, setSpokenIndex] = useState(-1);

  useEffect(() => {
    if (!quizRef.current) {
      const qs = generateQuiz();
      quizRef.current = qs;
      setQuestions(qs);
    }
    return () => { Speech.stop(); };
  }, []);

  useEffect(() => {
    if (isFinished) {
      saveQuizResult(score, TOTAL_QUESTIONS);
      const msg = getResultMessage(score);
      Speech.speak(msg, { language: 'pt-BR', pitch: 1.2 });
      return;
    }
    if (questions.length === 0) return;
    if (spokenIndex === currentIndex) return;

    setSpokenIndex(currentIndex);
    const q = questions[currentIndex];
    const isUpperCase = q.correctLetter === q.correctLetter.toUpperCase();
    const caseText = isUpperCase ? 'maiúscula' : 'minúscula';

    Speech.speak(`Qual desses é a letra ${q.correctLetter} ${caseText}?`, {
      language: 'pt-BR',
      pitch: 1.1,
    });
  }, [currentIndex, questions, isFinished, spokenIndex, score, saveQuizResult]);

  const handleOptionPress = (option: string) => {
    if (selectedOption !== null) return;

    const q = questions[currentIndex];
    const correct = option === q.correctLetter;

    setSelectedOption(option);
    setFeedbackType(correct ? 'correct' : 'wrong');

    if (correct) {
      setScore((prev) => prev + 1);
      Speech.speak('Muito bem!', { language: 'pt-BR', pitch: 1.2 });
    } else {
      Speech.speak(`Essa era a letra ${q.correctLetter}`, { language: 'pt-BR', pitch: 1.1 });
    }

    setTimeout(() => {
      if (currentIndex + 1 >= TOTAL_QUESTIONS) {
        Speech.stop();
        setIsFinished(true);
      } else {
        setSelectedOption(null);
        setFeedbackType(null);
        setCurrentIndex((prev) => prev + 1);
      }
    }, FEEDBACK_DELAY);
  };

  const handleReplay = () => {
    Speech.stop();
    quizRef.current = null;
    setQuestions([]);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setFeedbackType(null);
    setIsFinished(false);
    setSpokenIndex(-1);
  };

  if (isFinished) {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.resultContainer}>
            <MaterialCommunityIcons name="trophy" size={120} color="#FFD700" />
            <Text variant="headlineLarge" style={styles.resultTitle}>
              Parabéns!
            </Text>
            <Text variant="headlineMedium" style={styles.resultScore}>
              Você acertou {score} de {TOTAL_QUESTIONS}!
            </Text>
            <Text variant="titleLarge" style={styles.resultMessage}>
              {getResultMessage(score)}
            </Text>
            <View style={styles.resultButtons}>
              <Pressable
                style={styles.menuButton}
                onPress={() => {
                  Speech.speak('Voltar ao menu', { language: 'pt-BR', pitch: 1.2 });
                  setTimeout(() => router.back(), 300);
                }}
              >
                <MaterialCommunityIcons name="home" size={32} color="#ffffff" />
                <Text variant="headlineSmall" style={styles.buttonText}>Voltar ao Menu</Text>
              </Pressable>
              <Pressable
                style={styles.replayButton}
                onPress={() => {
                  Speech.speak('Jogar novamente', { language: 'pt-BR', pitch: 1.2 });
                  handleReplay();
                }}
              >
                <MaterialCommunityIcons name="replay" size={32} color="#ffffff" />
                <Text variant="headlineSmall" style={styles.buttonText}>Jogar Novamente</Text>
              </Pressable>
            </View>
          </View>
        </SafeAreaView>
      </>
    );
  }

  if (questions.length === 0) {
    return null;
  }

  const q = questions[currentIndex];
  const isUpperCase = q.correctLetter === q.correctLetter.toUpperCase();

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <View style={styles.header}>
            <IconButton icon="arrow-left" size={32} iconColor={colors.text} onPress={() => { Speech.stop(); router.back(); }} />
            <View style={styles.headerCenter}>
              <Text variant="titleMedium" style={styles.headerTitle}>
                Pergunta {currentIndex + 1} de {TOTAL_QUESTIONS}
              </Text>
              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${((currentIndex) / TOTAL_QUESTIONS) * 100}%` },
                  ]}
                />
              </View>
            </View>
            <View style={{ width: 48 }} />
          </View>

          <View style={styles.questionArea}>
            <View style={styles.chartContainer}>
              <CircularProgress
                progress={currentIndex / TOTAL_QUESTIONS}
                score={score}
                total={TOTAL_QUESTIONS}
                size={180}
                strokeWidth={16}
                colors={colors}
              />
              <MaterialCommunityIcons
                name="ear-hearing"
                size={36}
                color={colors.primary}
                style={styles.smallEarIcon}
              />
            </View>

            <View style={styles.grid}>
              {q.options.map((option) => {
                const isSelected = selectedOption === option;
                const isOptionCorrect = option === q.correctLetter;

                let cardStyle = styles.optionCard;
                let letterStyle = styles.optionLetter;

                if (feedbackType === 'correct' && isSelected) {
                  cardStyle = { ...cardStyle, ...styles.optionCardCorrect };
                  letterStyle = { ...letterStyle, ...styles.optionLetterCorrect };
                } else if (feedbackType === 'wrong' && isSelected) {
                  cardStyle = { ...cardStyle, ...styles.optionCardWrong };
                  letterStyle = { ...letterStyle, ...styles.optionLetterWrong };
                } else if (feedbackType === 'wrong' && isOptionCorrect) {
                  cardStyle = { ...cardStyle, ...styles.optionCardCorrect };
                  letterStyle = { ...letterStyle, ...styles.optionLetterCorrect };
                }

                return (
                  <Pressable
                    key={`${currentIndex}-${option}`}
                    style={cardStyle}
                    onPress={() => handleOptionPress(option)}
                  >
                    <Text style={letterStyle}>{option}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        </View>
      </SafeAreaView>
    </>
  );
}

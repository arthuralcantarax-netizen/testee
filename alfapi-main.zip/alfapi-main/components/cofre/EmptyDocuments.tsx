import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppTheme } from '@/contexts/ThemeContext';

export function EmptyDocuments() {
  const { colors } = useAppTheme();

  return (
    <View style={{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 40,
    }}>
      <MaterialCommunityIcons name="folder-open-outline" size={100} color={colors.textTertiary} />
      <Text variant="headlineSmall" style={{
        color: colors.textTertiary,
        marginTop: 16,
        textAlign: 'center',
      }}>
        Nenhum documento salvo
      </Text>
      <Text variant="bodyLarge" style={{
        color: colors.textTertiary,
        marginTop: 8,
        textAlign: 'center',
      }}>
        Toque no botão da câmera para adicionar fotos dos seus documentos
      </Text>
    </View>
  );
}

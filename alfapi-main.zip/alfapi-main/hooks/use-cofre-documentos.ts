import { useSQLiteContext } from 'expo-sqlite';
import { File, Directory, Paths } from 'expo-file-system';
import { useState, useCallback, useEffect } from 'react';
import { Document } from '@/types';

export function useCofreDocumentos() {
  const db = useSQLiteContext();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const getCofreDir = useCallback(() => {
    return new Directory(Paths.document, 'cofre');
  }, []);

  const ensureDirectory = useCallback(async () => {
    const dir = getCofreDir();
    if (!dir.exists) {
      dir.create({ intermediates: true });
    }
  }, [getCofreDir]);

  const loadDocuments = useCallback(async () => {
    setIsLoading(true);
    try {
      const all = await db.getAllAsync<Document>(
        'SELECT * FROM documents ORDER BY created_at DESC'
      );
      setDocuments(all);
    } catch (error) {
      console.error('Error loading documents:', error);
    } finally {
      setIsLoading(false);
    }
  }, [db]);

  const saveDocument = useCallback(async (uri: string) => {
    const timestamp = Date.now();
    const ext = uri.split('.').pop() || 'jpg';
    const filename = `doc_${timestamp}.${ext}`;

    await ensureDirectory();

    const sourceFile = new File(uri);
    const cofreDir = getCofreDir();
    const destFile = new File(cofreDir, filename);
    sourceFile.copy(destFile);

    await db.runAsync(
      `INSERT INTO documents (filename, original_name) VALUES (?, ?)`,
      filename,
      `Documento ${new Date(timestamp).toLocaleDateString('pt-BR')}`
    );

    await loadDocuments();
    return filename;
  }, [db, ensureDirectory, getCofreDir, loadDocuments]);

  const deleteDocument = useCallback(async (id: number, filename: string) => {
    try {
      const cofreDir = getCofreDir();
      const file = new File(cofreDir, filename);
      if (file.exists) {
        file.delete();
      }
      await db.runAsync('DELETE FROM documents WHERE id = ?', id);
      await loadDocuments();
    } catch (error) {
      console.error('Error deleting document:', error);
    }
  }, [db, getCofreDir, loadDocuments]);

  const getDocumentUri = useCallback((filename: string) => {
    const cofreDir = getCofreDir();
    return new File(cofreDir, filename).uri;
  }, [getCofreDir]);

  useEffect(() => {
    ensureDirectory().then(loadDocuments);
  }, [ensureDirectory, loadDocuments]);

  return {
    documents,
    isLoading,
    saveDocument,
    deleteDocument,
    getDocumentUri,
    loadDocuments,
  };
}
import { useSQLiteContext } from 'expo-sqlite';
import { useState, useCallback, useEffect } from 'react';
import { QuizResult } from '@/types';

export function useQuizResults() {
  const db = useSQLiteContext();
  const [results, setResults] = useState<QuizResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadResults = useCallback(async () => {
    try {
      const all = await db.getAllAsync<QuizResult>(
        'SELECT * FROM quiz_results ORDER BY date_taken DESC'
      );
      setResults(all);
    } catch (error) {
      console.error('Error loading quiz results:', error);
    } finally {
      setIsLoading(false);
    }
  }, [db]);

  const saveQuizResult = useCallback(async (score: number, total: number) => {
    await db.runAsync(
      'INSERT INTO quiz_results (score, total_questions) VALUES (?, ?)',
      score,
      total
    );
    await loadResults();
  }, [db, loadResults]);

  const totalCorrect = results.reduce((sum, r) => sum + r.score, 0);
  const totalQuestions = results.reduce((sum, r) => sum + r.total_questions, 0);
  const accuracyRate = totalQuestions > 0 ? totalCorrect / totalQuestions : 0;
  const sessionCount = results.length;

  useEffect(() => {
    loadResults();
  }, [loadResults]);

  return {
    results,
    isLoading,
    saveQuizResult,
    totalCorrect,
    totalQuestions,
    accuracyRate,
    sessionCount,
    refresh: loadResults,
  };
}

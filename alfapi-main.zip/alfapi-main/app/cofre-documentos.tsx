import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { View, FlatList, Pressable, Alert, Platform } from 'react-native';
import { Text, IconButton, FAB } from 'react-native-paper';
import { router, Stack } from 'expo-router';
import * as LocalAuthentication from 'expo-local-authentication';
import * as ImagePicker from 'expo-image-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { useCofreDocumentos } from '@/hooks/use-cofre-documentos';
import { Document } from '@/types';
import { AuthScreen, DeniedScreen } from '@/components/cofre/AuthScreen';
import { DocumentCard } from '@/components/cofre/DocumentCard';
import { EmptyDocuments } from '@/components/cofre/EmptyDocuments';
import { AddDocumentOptions } from '@/components/cofre/AddDocumentOptions';
import { DocumentViewerModal } from '@/components/cofre/DocumentViewerModal';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { createCofreStyles } from '@/styles/cofre.styles';

export default function CofreDocumentosScreen() {
  const { documents, isLoading, saveDocument, deleteDocument, getDocumentUri } = useCofreDocumentos();
  const { colors } = useAppTheme();
  const styles = useMemo(() => createCofreStyles(colors), [colors]);
  const [authState, setAuthState] = useState<'checking' | 'authenticating' | 'authenticated' | 'denied'>('checking');
  const [showOptions, setShowOptions] = useState(false);
  const [viewingDoc, setViewingDoc] = useState<Document | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Document | null>(null);

  useEffect(() => {
    checkAuthentication();
  }, []);

  const checkAuthentication = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      if (!hasHardware) {
        setAuthState('authenticated');
        return;
      }

      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      if (!isEnrolled) {
        setAuthState('authenticated');
        return;
      }

      setAuthState('authenticating');
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Autentique-se para acessar o Cofre',
        cancelLabel: 'Cancelar',
        disableDeviceFallback: false,
      });

      if (result.success) {
        setAuthState('authenticated');
      } else {
        setAuthState('denied');
        setTimeout(() => router.back(), 500);
      }
    } catch (error) {
      console.error('Auth error:', error);
      setAuthState('authenticated');
    }
  };

  const handlePickImage = useCallback(async (useCamera: boolean) => {
    setShowOptions(false);

    const options: ImagePicker.ImagePickerOptions = {
      mediaTypes: ['images'],
      quality: 0.8,
      allowsEditing: false,
    };

    try {
      let result: ImagePicker.ImagePickerResult;

      if (useCamera) {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) {
          Alert.alert('Permissão necessária', 'Precisamos de acesso à câmera para tirar fotos.');
          return;
        }
        result = await ImagePicker.launchCameraAsync(options);
      } else {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) {
          Alert.alert('Permissão necessária', 'Precisamos de acesso à galeria para escolher fotos.');
          return;
        }
        result = await ImagePicker.launchImageLibraryAsync(options);
      }

      if (!result.canceled && result.assets.length > 0) {
        Speech.speak('Documento salvo!', { language: 'pt-BR', pitch: 1.2 });
        await saveDocument(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Image picker error:', error);
    }
  }, [saveDocument]);

  const handleDelete = useCallback((doc: Document) => {
    Speech.speak('Se deseja excluir aperte o botão Verde, se não aperte o botão vermelho', { language: 'pt-BR', pitch: 1.1 });
    setDeleteTarget(doc);
  }, []);

  const confirmDelete = useCallback(() => {
    if (deleteTarget) {
      deleteDocument(deleteTarget.id, deleteTarget.filename);
      setDeleteTarget(null);
    }
  }, [deleteTarget, deleteDocument]);

  const handleViewDocument = useCallback((doc: Document) => {
    Speech.speak(`Documento de ${doc.created_at}`, { language: 'pt-BR', pitch: 1.1 });
    setViewingDoc(doc);
  }, []);

  if (authState === 'checking' || authState === 'authenticating') {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <SafeAreaView style={styles.authSafeArea}>
          <AuthScreen
            authState={authState}
            onCheckAuth={checkAuthentication}
            onBack={() => router.back()}
          />
        </SafeAreaView>
      </>
    );
  }

  if (authState === 'denied') {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <SafeAreaView style={styles.authSafeArea}>
          <DeniedScreen />
        </SafeAreaView>
      </>
    );
  }

  const renderDocument = ({ item }: { item: Document }) => {
    const uri = getDocumentUri(item.filename);
    return (
      <DocumentCard
        document={item}
        uri={uri}
        onPress={() => handleViewDocument(item)}
        onLongPress={() => handleDelete(item)}
      />
    );
  };

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <View style={styles.header}>
            <IconButton icon="arrow-left" size={32} iconColor={colors.text} onPress={() => router.back()} />
            <Text variant="titleLarge" style={styles.headerTitle}>Cofre de Documentos</Text>
            <View style={{ width: 48 }} />
          </View>

          <FlatList
            data={documents}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderDocument}
            ListEmptyComponent={EmptyDocuments}
            contentContainerStyle={documents.length === 0 ? styles.emptyList : styles.list}
            numColumns={2}
            columnWrapperStyle={documents.length > 0 ? styles.row : undefined}
            showsVerticalScrollIndicator={false}
          />

          {showOptions && (
            <Pressable style={styles.backdrop} onPress={() => setShowOptions(false)}>
              <AddDocumentOptions
                onPickCamera={() => handlePickImage(true)}
                onPickGallery={() => handlePickImage(false)}
                onDismiss={() => setShowOptions(false)}
              />
            </Pressable>
          )}

          <FAB
            icon="camera"
            style={styles.fab}
            onPress={() => {
              Speech.speak('Adicionar documento', { language: 'pt-BR', pitch: 1.1 });
              setShowOptions(true);
            }}
            color="#ffffff"
            size="large"
          />

          <DocumentViewerModal
            document={viewingDoc}
            uri={viewingDoc ? getDocumentUri(viewingDoc.filename) : ''}
            onClose={() => setViewingDoc(null)}
            onDelete={(doc) => {
              setViewingDoc(null);
              handleDelete(doc);
            }}
          />

          <ConfirmDialog
            visible={deleteTarget !== null}
            icon="alert-circle"
            iconColor={colors.danger}
            title="Excluir Documento"
            message="Tem certeza que deseja excluir este documento?"
            speechText="Se deseja excluir aperte o botão Verde, se não aperte o botão vermelho"
            onConfirm={confirmDelete}
            onDismiss={() => deleteTarget ? setDeleteTarget(null) : null}
          />
        </View>
      </SafeAreaView>
    </>
  );
}

import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { Canvas, Circle, Path, Skia } from '@shopify/react-native-skia';
import { AppColors } from '@/constants/themes';

interface CircularProgressProps {
  progress: number;
  score: number;
  total: number;
  size: number;
  strokeWidth: number;
  colors: AppColors;
}

export function CircularProgress({ progress, score, total, size, strokeWidth, colors }: CircularProgressProps) {
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;

  const progressPath = Skia.Path.Make();
  if (progress > 0) {
    if (progress >= 1) {
      progressPath.addCircle(center, center, radius);
    } else {
      progressPath.addArc(
        { x: center - radius, y: center - radius, width: radius * 2, height: radius * 2 },
        -90,
        360 * progress,
      );
    }
  }

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Canvas style={{ width: size, height: size }}>
        <Circle cx={center} cy={center} r={radius} color={colors.progressBackground} style="stroke" strokeWidth={strokeWidth} />
        {progress > 0 && (
          <Path path={progressPath} color={colors.success} style="stroke" strokeWidth={strokeWidth} strokeCap="round" />
        )}
      </Canvas>
      <View style={{ position: 'absolute', alignItems: 'center' }}>
        <Text variant="displayMedium" style={{ fontWeight: '700', color: colors.text, marginBottom: -8 }}>
          {score}
        </Text>
        <Text variant="titleSmall" style={{ color: colors.textSecondary }}>
          de {total}
        </Text>
      </View>
    </View>
  );
}

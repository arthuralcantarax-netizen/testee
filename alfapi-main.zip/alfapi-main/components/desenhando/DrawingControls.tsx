import { View, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';

interface DrawingControlsProps {
  onClear: () => void;
  onCheck: () => void;
  isChecking: boolean;
}

export function DrawingControls({ onClear, onCheck, isChecking }: DrawingControlsProps) {
  const { colors } = useAppTheme();

  return (
    <View style={{
      flexDirection: 'row',
      justifyContent: 'center',
      gap: 24,
      paddingVertical: 24,
    }}>
      <Pressable
        style={{
          backgroundColor: colors.danger,
          paddingVertical: 22,
          paddingHorizontal: 28,
          borderRadius: 12,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
        }}
        onPress={() => {
          Speech.speak('Limpar desenho', { language: 'pt-BR', pitch: 1.1 });
          onClear();
        }}
      >
        <MaterialCommunityIcons name="eraser" size={32} color="#ffffff" />
        <Text variant="titleLarge" style={{ color: '#ffffff', fontWeight: '700', fontSize: 20 }}>Limpar</Text>
      </Pressable>
      <Pressable
        style={[{
          backgroundColor: colors.success,
          paddingVertical: 22,
          paddingHorizontal: 28,
          borderRadius: 12,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
        }, isChecking && { backgroundColor: colors.successLight }]}
        onPress={onCheck}
        disabled={isChecking}
      >
        <MaterialCommunityIcons name="check-circle" size={32} color="#ffffff" />
        <Text variant="titleLarge" style={{ color: '#ffffff', fontWeight: '700', fontSize: 20 }}>Verificar</Text>
      </Pressable>
    </View>
  );
}

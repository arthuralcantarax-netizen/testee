import { useState, useMemo } from 'react';
import { View, Image } from 'react-native';
import { TextInput, Button, Text } from 'react-native-paper';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/contexts/ThemeContext';
import { createLoginStyles } from '@/styles/login.styles';
import logo from '../assets/images/logo-login.png';

export default function LoginScreen() {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createLoginStyles(colors), [colors]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    router.replace('/menu');
  };

  return (
      <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.logoContainer}>
          <Image source={logo} style={styles.logo} />
        </View>
        <Text variant="headlineMedium" style={styles.title}>
          Login
        </Text>

        <TextInput
          label="Email"
          value={email}
          onChangeText={setEmail}
          mode="outlined"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
        />

        <TextInput
          label="Senha"
          value={password}
          onChangeText={setPassword}
          mode="outlined"
          secureTextEntry
          style={styles.input}
        />

        <Button mode="contained" onPress={handleLogin} style={styles.button}>
          Login
        </Button>

        <Button mode="outlined" onPress={handleLogin} style={styles.button}>
          Login com GOV.BR
        </Button>

        <Button mode="text" onPress={handleLogin} style={styles.button}>
          Recuperar Conta
        </Button>
      </View>
    </SafeAreaView>
  );
}

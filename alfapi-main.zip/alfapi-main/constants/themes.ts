export type AppThemeName = 'default' | 'high-contrast' | 'dark' | 'deuteranopia' | 'protanopia';

export type AppColors = {
  background: string;
  surface: string;
  primary: string;
  text: string;
  textSecondary: string;
  textTertiary: string;
  success: string;
  danger: string;
  border: string;
  canvasBackground: string;
  buttonBackground: string;
  iconColor: string;
  overlay: string;
  dialogBackground: string;
  progressBackground: string;
  successLight: string;
};

export const themes: Record<AppThemeName, AppColors> = {
  default: {
    background: '#ffffff',
    surface: '#f5f5f5',
    primary: '#0a7ea4',
    text: '#333333',
    textSecondary: '#666666',
    textTertiary: '#999999',
    success: '#66bb6a',
    danger: '#ff4444',
    border: '#e0e0e0',
    canvasBackground: '#ffffff',
    buttonBackground: '#f5f5f5',
    iconColor: '#0a7ea4',
    overlay: 'rgba(0,0,0,0.5)',
    dialogBackground: '#ffffff',
    progressBackground: '#e0e0e0',
    successLight: '#a5d6a7',
  },
  'high-contrast': {
    background: '#ffffff',
    surface: '#ffffff',
    primary: '#0000cc',
    text: '#000000',
    textSecondary: '#1a1a1a',
    textTertiary: '#333333',
    success: '#006400',
    danger: '#8b0000',
    border: '#000000',
    canvasBackground: '#ffffff',
    buttonBackground: '#ffffff',
    iconColor: '#000000',
    overlay: 'rgba(0,0,0,0.6)',
    dialogBackground: '#ffffff',
    progressBackground: '#cccccc',
    successLight: '#90ee90',
  },
  dark: {
    background: '#121212',
    surface: '#1e1e2e',
    primary: '#4fc3f7',
    text: '#e0e0e0',
    textSecondary: '#9e9e9e',
    textTertiary: '#6b7280',
    success: '#4caf50',
    danger: '#ef5350',
    border: '#374151',
    canvasBackground: '#1e1e2e',
    buttonBackground: '#2a2a3e',
    iconColor: '#4fc3f7',
    overlay: 'rgba(0,0,0,0.7)',
    dialogBackground: '#1e1e2e',
    progressBackground: '#374151',
    successLight: '#388e3c',
  },
  deuteranopia: {
    background: '#ffffff',
    surface: '#f5f5f5',
    primary: '#0055cc',
    text: '#333333',
    textSecondary: '#666666',
    textTertiary: '#999999',
    success: '#0055cc',
    danger: '#cc5500',
    border: '#b0b0b0',
    canvasBackground: '#ffffff',
    buttonBackground: '#e8f0fe',
    iconColor: '#0055cc',
    overlay: 'rgba(0,0,0,0.5)',
    dialogBackground: '#ffffff',
    progressBackground: '#d0d0d0',
    successLight: '#7ab8ff',
  },
  protanopia: {
    background: '#ffffff',
    surface: '#f5f5f5',
    primary: '#0055cc',
    text: '#333333',
    textSecondary: '#666666',
    textTertiary: '#999999',
    success: '#008844',
    danger: '#cc8800',
    border: '#b0b0b0',
    canvasBackground: '#ffffff',
    buttonBackground: '#e8f0fe',
    iconColor: '#0055cc',
    overlay: 'rgba(0,0,0,0.5)',
    dialogBackground: '#ffffff',
    progressBackground: '#d0d0d0',
    successLight: '#66bb66',
  },
};

export const themeLabels: Record<AppThemeName, string> = {
  default: 'Padrão',
  'high-contrast': 'Alto Contraste',
  dark: 'Escuro',
  deuteranopia: 'Deuteranopia',
  protanopia: 'Protanopia',
};

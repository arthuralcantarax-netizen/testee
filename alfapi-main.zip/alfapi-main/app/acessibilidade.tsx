import { useCallback } from 'react';
import { View, ScrollView, Pressable } from 'react-native';
import { Text, IconButton } from 'react-native-paper';
import { router, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { AppThemeName, themes, themeLabels } from '@/constants/themes';
import { createAcessibilidadeStyles } from '@/styles/acessibilidade.styles';

const themeOrder: AppThemeName[] = ['default', 'high-contrast', 'dark', 'deuteranopia', 'protanopia'];

function ThemePreview({ themeName }: { themeName: AppThemeName }) {
  const c = themes[themeName];
  const dotSize = 16;
  return (
    <View style={{ width: 48, height: 48, borderRadius: 12, backgroundColor: c.background, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: c.border }}>
      <View style={{ flexDirection: 'row', gap: 3 }}>
        <View style={{ width: dotSize, height: dotSize, borderRadius: dotSize / 2, backgroundColor: c.primary }} />
        <View style={{ width: dotSize, height: dotSize, borderRadius: dotSize / 2, backgroundColor: c.success }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 3, marginTop: 3 }}>
        <View style={{ width: dotSize, height: dotSize, borderRadius: dotSize / 2, backgroundColor: c.danger }} />
        <View style={{ width: dotSize, height: dotSize, borderRadius: dotSize / 2, backgroundColor: c.surface }} />
      </View>
    </View>
  );
}

export default function AcessibilidadeScreen() {
  const { themeName, colors, setTheme } = useAppTheme();
  const styles = createAcessibilidadeStyles(colors);

  const handleSelect = useCallback(async (name: AppThemeName) => {
    Speech.speak(themeLabels[name], { language: 'pt-BR', pitch: 1.2 });
    await setTheme(name);
  }, [setTheme]);

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <IconButton icon="arrow-left" size={32} iconColor={colors.text} onPress={() => router.back()} />
          <Text variant="headlineSmall" style={styles.headerTitle}>Acessibilidade</Text>
        </View>
        <ScrollView contentContainerStyle={styles.list}>
          {themeOrder.map((name) => {
            const selected = themeName === name;
            return (
              <Pressable
                key={name}
                style={[styles.themeCard, selected && styles.themeCardSelected]}
                onPress={() => handleSelect(name)}
              >
                <ThemePreview themeName={name} />
                <View style={styles.themeInfo}>
                  <Text variant="titleLarge" style={styles.themeName}>
                    {themeLabels[name]}
                  </Text>
                  <Text variant="bodyLarge" style={styles.themeSubtitle}>
                    {name === 'default' && 'Padrão do sistema'}
                    {name === 'high-contrast' && 'Máximo contraste para visão reduzida'}
                    {name === 'dark' && 'Fundo escuro para conforto visual'}
                    {name === 'deuteranopia' && 'Adaptado para daltonismo verde-vermelho'}
                    {name === 'protanopia' && 'Adaptado para daltonismo vermelho-verde'}
                  </Text>
                </View>
                {selected && (
                  <MaterialCommunityIcons name="check-circle" size={28} color={colors.primary} style={styles.checkmark} />
                )}
              </Pressable>
            );
          })}
        </ScrollView>
      </SafeAreaView>
    </>
  );
}

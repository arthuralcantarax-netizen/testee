import { StyleSheet, Dimensions } from 'react-native';
import { AppColors } from '@/constants/themes';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export function createCofreStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    authSafeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 8,
      paddingVertical: 8,
      backgroundColor: colors.background,
    },
    headerTitle: {
      fontWeight: '600',
      color: colors.text,
    },
    list: {
      padding: 12,
      paddingBottom: 100,
    },
    emptyList: {
      flexGrow: 1,
    },
    row: {
      justifyContent: 'space-between',
      marginBottom: 12,
    },
    cardPressable: {
      width: '48%',
    },
    cardPressed: {
      opacity: 0.8,
    },
    card: {
      borderRadius: 12,
      elevation: 2,
    },
    cardCover: {
      height: 140,
      borderTopLeftRadius: 12,
      borderTopRightRadius: 12,
    },
    cardContent: {
      paddingVertical: 8,
      paddingHorizontal: 10,
    },
    cardDate: {
      color: colors.textTertiary,
      marginTop: 2,
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 40,
    },
    emptyText: {
      color: colors.textTertiary,
      marginTop: 16,
      textAlign: 'center',
    },
    emptySubtext: {
      color: colors.textTertiary,
      marginTop: 8,
      textAlign: 'center',
    },
    fab: {
      position: 'absolute',
      right: 24,
      bottom: 32,
      backgroundColor: colors.primary,
      borderRadius: 32,
      elevation: 6,
      shadowColor: '#000',
      shadowOffset: { width: 2, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 4,
    },
    backdrop: {
      ...StyleSheet.absoluteFillObject,
      backgroundColor: colors.overlay,
      justifyContent: 'flex-end',
      zIndex: 10,
    },
    optionsContainer: {
      backgroundColor: colors.dialogBackground,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      padding: 24,
      paddingBottom: 40,
    },
    optionsTitle: {
      textAlign: 'center',
      marginBottom: 20,
      fontWeight: '600',
      color: colors.text,
    },
    optionButton: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 16,
      paddingVertical: 16,
      paddingHorizontal: 20,
      borderRadius: 12,
      backgroundColor: colors.surface,
      marginBottom: 12,
    },
    optionText: {
      color: colors.primary,
      fontWeight: '500',
    },
    optionCancel: {
      alignItems: 'center',
      paddingVertical: 12,
      marginTop: 4,
    },
    optionCancelText: {
      color: colors.textSecondary,
    },
    authContainer: {
      flex: 1,
      backgroundColor: colors.background,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 32,
    },
    authText: {
      textAlign: 'center',
      marginTop: 24,
      marginBottom: 32,
      color: colors.text,
    },
    retryButton: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: colors.primary,
      paddingVertical: 14,
      paddingHorizontal: 28,
      borderRadius: 12,
      marginBottom: 16,
    },
    retryText: {
      color: '#ffffff',
      fontWeight: '600',
    },
    cancelButton: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      paddingVertical: 14,
      paddingHorizontal: 28,
    },
    cancelText: {
      color: colors.primary,
      fontWeight: '600',
    },
    modalContainer: {
      flex: 1,
      backgroundColor: colors.overlay,
      justifyContent: 'center',
      alignItems: 'center',
    },
    modalClose: {
      position: 'absolute',
      top: 50,
      right: 20,
      zIndex: 10,
      padding: 8,
    },
    modalImage: {
      width: SCREEN_WIDTH,
      height: SCREEN_HEIGHT * 0.7,
    },
    modalDelete: {
      position: 'absolute',
      bottom: 60,
      padding: 12,
      borderRadius: 30,
    },
  });
}

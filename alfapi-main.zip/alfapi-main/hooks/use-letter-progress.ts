import { useSQLiteContext } from 'expo-sqlite';
import { useState, useCallback, useEffect } from 'react';
import { LetterProgress } from '@/types';

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

const LETTER_SEQUENCE: string[] = [];
ALPHABET.forEach(letter => {
  LETTER_SEQUENCE.push(letter);
  LETTER_SEQUENCE.push(letter.toLowerCase());
});

export function useLetterProgress() {
  const db = useSQLiteContext();
  const [progress, setProgress] = useState<LetterProgress[]>([]);
  const [currentLetter, setCurrentLetter] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const initializeDatabase = useCallback(async () => {
    try {
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS letter_progress (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          letter TEXT NOT NULL UNIQUE,
          attempts INTEGER NOT NULL DEFAULT 0,
          best_score REAL NOT NULL DEFAULT 0,
          mastered INTEGER NOT NULL DEFAULT 0,
          last_practiced_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);

      const existing = await db.getAllAsync<{ letter: string }>('SELECT letter FROM letter_progress');
      
      const hasOldData = existing.some(e => e.letter.length > 1);
      if (hasOldData) {
        await db.execAsync('DELETE FROM letter_progress');
        existing.length = 0;
      }
      
      const existingLetters = new Set(existing.map(e => e.letter));

      for (const letter of LETTER_SEQUENCE) {
        if (!existingLetters.has(letter)) {
          await db.runAsync('INSERT INTO letter_progress (letter) VALUES (?)', letter);
        }
      }
    } catch (error) {
      console.error('Error initializing database:', error);
    }
  }, [db]);

  const loadProgress = useCallback(async () => {
    setIsLoading(true);
    try {
      const all = await db.getAllAsync<LetterProgress>('SELECT * FROM letter_progress ORDER BY id');
      setProgress(all);

      const nextLetter = all.find(p => p.mastered === 0);
      setCurrentLetter(nextLetter?.letter || null);
    } catch (error) {
      console.error('Error loading progress:', error);
    } finally {
      setIsLoading(false);
    }
  }, [db]);

  const saveAttempt = useCallback(async (letter: string, score: number) => {
    const mastered = score >= 0.3 ? 1 : 0;
    await db.runAsync(
      `UPDATE letter_progress
       SET attempts = attempts + 1,
           best_score = MAX(best_score, ?),
           mastered = MAX(mastered, ?),
           last_practiced_at = datetime('now')
       WHERE letter = ?`,
      score, mastered, letter
    );
    await loadProgress();
  }, [db, loadProgress]);

  const resetProgress = useCallback(async () => {
    await db.runAsync('DELETE FROM letter_progress');
    for (const letter of LETTER_SEQUENCE) {
      await db.runAsync('INSERT INTO letter_progress (letter) VALUES (?)', letter);
    }
    await loadProgress();
  }, [db, loadProgress]);

  const getMasteredCount = useCallback(() => {
    return progress.filter(p => p.mastered === 1).length;
  }, [progress]);

  const isComplete = useCallback(() => {
    return progress.length > 0 && progress.every(p => p.mastered === 1);
  }, [progress]);

  useEffect(() => {
    initializeDatabase().then(loadProgress);
  }, [initializeDatabase, loadProgress]);

  return {
    currentLetter,
    progress,
    isLoading,
    saveAttempt,
    resetProgress,
    getMasteredCount,
    isComplete,
    totalLetters: LETTER_SEQUENCE.length
  };
}
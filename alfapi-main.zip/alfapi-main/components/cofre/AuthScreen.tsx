import { View, Pressable, Platform } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';

interface AuthScreenProps {
  authState: 'checking' | 'authenticating';
  onCheckAuth: () => void;
  onBack: () => void;
}

export function AuthScreen({ authState, onCheckAuth, onBack }: AuthScreenProps) {
  const { colors } = useAppTheme();

  return (
    <View style={{
      flex: 1,
      backgroundColor: colors.background,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 32,
    }}>
      <MaterialCommunityIcons name="shield-lock" size={80} color={colors.iconColor} />
      <Text variant="headlineMedium" style={{
        textAlign: 'center',
        marginTop: 24,
        marginBottom: 32,
        color: colors.text,
      }}>
        {authState === 'authenticating'
          ? 'Autentique-se para acessar o Cofre'
          : 'Verificando autenticação...'}
      </Text>
      {authState === 'authenticating' && Platform.OS !== 'web' && (
        <Pressable
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 8,
            backgroundColor: colors.primary,
            paddingVertical: 14,
            paddingHorizontal: 28,
            borderRadius: 12,
            marginBottom: 16,
          }}
          onPress={() => {
            Speech.speak('Tentar novamente', { language: 'pt-BR', pitch: 1.1 });
            onCheckAuth();
          }}
        >
          <MaterialCommunityIcons name="fingerprint" size={28} color="#ffffff" />
          <Text variant="titleMedium" style={{ color: '#ffffff', fontWeight: '600' }}>Tentar novamente</Text>
        </Pressable>
      )}
      <Pressable
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
          paddingVertical: 14,
          paddingHorizontal: 28,
        }}
        onPress={() => {
          Speech.speak('Voltar ao menu', { language: 'pt-BR', pitch: 1.1 });
          onBack();
        }}
      >
        <MaterialCommunityIcons name="arrow-left" size={28} color={colors.primary} />
        <Text variant="titleMedium" style={{ color: colors.primary, fontWeight: '600' }}>Voltar ao Menu</Text>
      </Pressable>
    </View>
  );
}

export function DeniedScreen() {
  const { colors } = useAppTheme();

  return (
    <View style={{
      flex: 1,
      backgroundColor: colors.background,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 32,
    }}>
      <MaterialCommunityIcons name="lock" size={80} color={colors.danger} />
      <Text variant="headlineMedium" style={{
        textAlign: 'center',
        marginTop: 24,
        marginBottom: 32,
        color: colors.text,
      }}>
        Acesso negado
      </Text>
    </View>
  );
}

import { View, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';

interface AddDocumentOptionsProps {
  onPickCamera: () => void;
  onPickGallery: () => void;
  onDismiss: () => void;
}

export function AddDocumentOptions({ onPickCamera, onPickGallery, onDismiss }: AddDocumentOptionsProps) {
  const { colors } = useAppTheme();

  return (
    <View style={{
      backgroundColor: colors.dialogBackground,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      padding: 24,
      paddingBottom: 40,
    }}>
      <Text variant="titleMedium" style={{
        textAlign: 'center',
        marginBottom: 20,
        fontWeight: '600',
        color: colors.text,
      }}>
        Adicionar Documento
      </Text>
      <Pressable
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 16,
          paddingVertical: 16,
          paddingHorizontal: 20,
          borderRadius: 12,
          backgroundColor: colors.surface,
          marginBottom: 12,
        }}
        onPress={() => {
          Speech.speak('Tirar foto', { language: 'pt-BR', pitch: 1.1 });
          onPickCamera();
        }}
      >
        <MaterialCommunityIcons name="camera" size={32} color={colors.primary} />
        <Text variant="titleMedium" style={{ color: colors.primary, fontWeight: '500' }}>Tirar Foto</Text>
      </Pressable>
      <Pressable
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 16,
          paddingVertical: 16,
          paddingHorizontal: 20,
          borderRadius: 12,
          backgroundColor: colors.surface,
          marginBottom: 12,
        }}
        onPress={() => {
          Speech.speak('Escolher da galeria', { language: 'pt-BR', pitch: 1.1 });
          onPickGallery();
        }}
      >
        <MaterialCommunityIcons name="image-multiple" size={32} color={colors.primary} />
        <Text variant="titleMedium" style={{ color: colors.primary, fontWeight: '500' }}>Escolher da Galeria</Text>
      </Pressable>
      <Pressable
        style={{
          alignItems: 'center',
          paddingVertical: 12,
          marginTop: 4,
        }}
        onPress={onDismiss}
      >
        <Text variant="titleMedium" style={{ color: colors.textSecondary }}>Cancelar</Text>
      </Pressable>
    </View>
  );
}

import { StyleSheet } from 'react-native';
import { AppColors } from '@/constants/themes';

export function createFalandoStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingVertical: 8,
    },
    headerCenter: {
      flex: 1,
      alignItems: 'center',
    },
    headerTitle: {
      color: colors.text,
      fontWeight: '600',
    },
    progressBar: {
      width: '80%',
      height: 8,
      backgroundColor: colors.progressBackground,
      borderRadius: 4,
      marginTop: 4,
    },
    progressFill: {
      height: '100%',
      backgroundColor: colors.primary,
      borderRadius: 4,
    },
    questionArea: {
      flex: 1,
      justifyContent: 'center',
      paddingHorizontal: 24,
    },
    chartContainer: {
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20,
      paddingVertical: 8,
    },
    smallEarIcon: {
      marginTop: 12,
    },
    grid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      paddingHorizontal: 16,
    },
    optionCard: {
      width: '48%',
      aspectRatio: 1.3,
      borderRadius: 20,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 16,
      backgroundColor: colors.buttonBackground,
      borderWidth: 3,
      borderColor: colors.border,
    },
    optionCardCorrect: {
      backgroundColor: colors.success,
      borderColor: colors.success,
    },
    optionCardWrong: {
      backgroundColor: colors.danger,
      borderColor: colors.danger,
    },
    optionLetter: {
      fontSize: 64,
      fontWeight: '700',
      color: colors.text,
    },
    optionLetterCorrect: {
      color: '#ffffff',
    },
    optionLetterWrong: {
      color: '#ffffff',
    },
    resultContainer: {
      flex: 1,
      backgroundColor: colors.background,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 24,
    },
    resultTitle: {
      fontWeight: '700',
      color: colors.text,
      marginTop: 24,
      fontSize: 36,
      textAlign: 'center',
    },
    resultScore: {
      color: colors.primary,
      marginTop: 8,
      fontWeight: '700',
      fontSize: 28,
    },
    resultMessage: {
      color: colors.textSecondary,
      marginTop: 8,
      marginBottom: 48,
      textAlign: 'center',
      fontSize: 20,
    },
    resultButtons: {
      flexDirection: 'row',
      gap: 20,
      flexWrap: 'wrap',
      justifyContent: 'center',
    },
    menuButton: {
      backgroundColor: colors.primary,
      paddingVertical: 20,
      paddingHorizontal: 32,
      borderRadius: 16,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      minWidth: 200,
      justifyContent: 'center',
    },
    replayButton: {
      backgroundColor: colors.success,
      paddingVertical: 20,
      paddingHorizontal: 32,
      borderRadius: 16,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      minWidth: 200,
      justifyContent: 'center',
    },
    buttonText: {
      color: '#ffffff',
      fontWeight: '700',
      fontSize: 18,
    },
  });
}

import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import { AppColors } from '@/constants/themes';

interface QuizHistoryChartProps {
  accuracyRate: number;
  size: number;
  strokeWidth: number;
  colors: AppColors;
}

export function QuizHistoryChart({ accuracyRate, size, strokeWidth, colors }: QuizHistoryChartProps) {
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const rect = { x: center - radius, y: center - radius, width: radius * 2, height: radius * 2 };

  const greenAngle = 360 * accuracyRate;
  const redAngle = 360 * (1 - accuracyRate);

  const greenPath = Skia.Path.Make();
  const redPath = Skia.Path.Make();

  if (greenAngle > 0) {
    greenPath.addArc(rect, -90, greenAngle);
  }
  if (redAngle > 0) {
    redPath.addArc(rect, -90 + greenAngle, redAngle);
  }

  const percentText = accuracyRate > 0 ? Math.round(accuracyRate * 100) : 0;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Canvas style={{ width: size, height: size }}>
        {greenAngle > 0 && (
          <Path path={greenPath} color={colors.success} style="stroke" strokeWidth={strokeWidth} strokeCap="butt" />
        )}
        {redAngle > 0 && (
          <Path path={redPath} color={colors.danger} style="stroke" strokeWidth={strokeWidth} strokeCap="butt" />
        )}
      </Canvas>
      <View style={{ position: 'absolute', alignItems: 'center' }}>
        <Text variant="displayMedium" style={{ fontWeight: '700', color: colors.text, marginBottom: -8 }}>
          {percentText}%
        </Text>
        <Text variant="titleSmall" style={{ color: colors.textSecondary }}>
          acertos
        </Text>
      </View>
    </View>
  );
}

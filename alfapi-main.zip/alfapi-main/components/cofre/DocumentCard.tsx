import { Pressable } from 'react-native';
import { Text, Card } from 'react-native-paper';
import { Document } from '@/types';
import { useAppTheme } from '@/contexts/ThemeContext';

interface DocumentCardProps {
  document: Document;
  uri: string;
  onPress: () => void;
  onLongPress: () => void;
}

export function DocumentCard({ document, uri, onPress, onLongPress }: DocumentCardProps) {
  const { colors } = useAppTheme();

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      style={({ pressed }) => [
        { width: '48%' },
        pressed && { opacity: 0.8 },
      ]}
    >
      <Card style={{
        borderRadius: 12,
        elevation: 2,
        backgroundColor: colors.surface,
      }}>
        <Card.Cover source={{ uri }} style={{
          height: 140,
          borderTopLeftRadius: 12,
          borderTopRightRadius: 12,
        }} />
        <Card.Content style={{
          paddingVertical: 8,
          paddingHorizontal: 10,
        }}>
          <Text variant="titleSmall" numberOfLines={1} style={{ color: colors.text }}>{document.original_name}</Text>
          <Text variant="bodySmall" style={{
            color: colors.textTertiary,
            marginTop: 2,
          }}>
            {new Date(document.created_at + 'Z').toLocaleDateString('pt-BR')}
          </Text>
        </Card.Content>
      </Card>
    </Pressable>
  );
}

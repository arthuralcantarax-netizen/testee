import { useMemo } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';
import { MenuButton } from '@/components/MenuButton';
import { createMenuStyles } from '@/styles/menu.styles';

export default function MenuScreen() {
  const { colors } = useAppTheme();
  const styles = useMemo(() => createMenuStyles(colors), [colors]);

  const handleAprendaDesenhando = () => {
    Speech.speak('Aprenda Desenhando', { language: 'pt-BR', pitch: 1.2 });
    router.push('/aprenda-desenhando');
  };

  const handleAprendaFalando = () => {
    Speech.speak('Aprenda Escutando', { language: 'pt-BR', pitch: 1.2 });
    router.push('/aprenda-falando');
  };

  const handleCofreDocumentos = () => {
    Speech.speak('Cofre de Documentos', { language: 'pt-BR', pitch: 1.2 });
    router.push('/cofre-documentos');
  };

  const handlePainelAluno = () => {
    Speech.speak('Painel do Aluno', { language: 'pt-BR', pitch: 1.2 });
    router.push('/painel-aluno');
  };

  const handleAcessibilidade = () => {
    Speech.speak('Acessibilidade', { language: 'pt-BR', pitch: 1.2 });
    router.push('/acessibilidade');
  };

  const handleSair = () => {
    Speech.speak('Sair', { language: 'pt-BR', pitch: 1.2 });
    setTimeout(() => router.replace('/'), 300);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.grid}>
          <MenuButton title="Aprenda Desenhando" icon="pencil" onPress={handleAprendaDesenhando} />
          <MenuButton title="Aprenda Escutando" icon="ear-hearing" onPress={handleAprendaFalando} />
          <MenuButton title="Cofre de Documentos" icon="folder-lock" onPress={handleCofreDocumentos} />
          <MenuButton title="Painel do Aluno" icon="chart-bar" onPress={handlePainelAluno} />
          <MenuButton title="Acessibilidade" icon="human" onPress={handleAcessibilidade} />
          <MenuButton title="Sair" icon="exit-run" onPress={handleSair} />
        </View>
      </View>
    </SafeAreaView>
  );
}

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { useSQLiteContext } from 'expo-sqlite';
import { AppThemeName, AppColors, themes } from '@/constants/themes';

interface ThemeContextType {
  themeName: AppThemeName;
  colors: AppColors;
  setTheme: (name: AppThemeName) => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType>({
  themeName: 'default',
  colors: themes.default,
  setTheme: async () => {},
});

export function AppThemeProvider({ children }: { children: ReactNode }) {
  const [themeName, setThemeName] = useState<AppThemeName>('default');
  const db = useSQLiteContext();

  useEffect(() => {
    (async () => {
      try {
        const row = await db.getFirstAsync<{ value: string }>(
          'SELECT value FROM settings WHERE key = ?',
          'app_theme'
        );
        if (row && row.value in themes) {
          setThemeName(row.value as AppThemeName);
        }
      } catch {}
    })();
  }, []);

  const setTheme = useCallback(async (name: AppThemeName) => {
    setThemeName(name);
    try {
      await db.runAsync(
        'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
        'app_theme',
        name
      );
    } catch (e) {
      console.error('Failed to save theme', e);
    }
  }, [db]);

  return (
    <ThemeContext.Provider value={{ themeName, colors: themes[themeName], setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useAppTheme() {
  return useContext(ThemeContext);
}

import { StyleSheet } from 'react-native';
import { AppColors } from '@/constants/themes';

export function createMenuStyles(colors: AppColors) {
  return StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    container: {
      flex: 1,
      justifyContent: 'center',
      padding: 16,
    },
    grid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      alignContent: 'space-between',
    },
    button: {
      width: '48%',
      aspectRatio: 1,
      backgroundColor: colors.buttonBackground,
      borderRadius: 16,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 16,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    },
    buttonText: {
      marginTop: 12,
      textAlign: 'center',
      fontWeight: '600',
      color: colors.text,
    },
  });
}

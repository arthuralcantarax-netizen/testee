import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { PaperProvider, MD3LightTheme } from 'react-native-paper';
import { SQLiteProvider } from 'expo-sqlite';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import 'react-native-reanimated';

import { useColorScheme } from '@/hooks/use-color-scheme';
import { AppThemeProvider, useAppTheme } from '@/contexts/ThemeContext';

async function migrateDb(db: any) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS letter_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      letter TEXT NOT NULL UNIQUE,
      attempts INTEGER NOT NULL DEFAULT 0,
      best_score REAL NOT NULL DEFAULT 0,
      mastered INTEGER NOT NULL DEFAULT 0,
      last_practiced_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS quiz_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      score INTEGER NOT NULL,
      total_questions INTEGER NOT NULL DEFAULT 20,
      date_taken TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  await db.execAsync(`PRAGMA user_version = 2`);
}

function AppContent() {
  const { colors } = useAppTheme();
  const colorScheme = useColorScheme();

  const paperTheme = {
    ...MD3LightTheme,
    colors: {
      ...MD3LightTheme.colors,
      primary: colors.primary,
      background: colors.background,
      surface: colors.surface,
      text: colors.text,
    },
  };

  return (
    <PaperProvider theme={paperTheme}>
      <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <Stack>
          <Stack.Screen name="index" options={{ headerShown: false }} />
          <Stack.Screen name="menu" options={{ headerShown: false }} />
          <Stack.Screen name="acessibilidade" options={{ headerShown: false }} />
          <Stack.Screen name="aprenda-desenhando" options={{ headerShown: false }} />
          <Stack.Screen name="aprenda-falando" options={{ headerShown: false }} />
          <Stack.Screen name="cofre-documentos" options={{ headerShown: false }} />
          <Stack.Screen name="painel-aluno" options={{ headerShown: false }} />
          <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
        </Stack>
        <StatusBar style="dark" backgroundColor={colors.background} />
      </ThemeProvider>
    </PaperProvider>
  );
}

export default function RootLayout() {
  return (
    <SQLiteProvider databaseName="alfapi.db" onInit={migrateDb}>
      <SafeAreaProvider>
        <AppThemeProvider>
          <AppContent />
        </AppThemeProvider>
      </SafeAreaProvider>
    </SQLiteProvider>
  );
}

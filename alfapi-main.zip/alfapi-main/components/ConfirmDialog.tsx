import { Modal, View, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';

interface ConfirmDialogProps {
  visible: boolean;
  icon: string;
  iconColor: string;
  title: string;
  message: string;
  speechText: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onDismiss: () => void;
}

export function ConfirmDialog({
  visible,
  icon,
  iconColor,
  title,
  message,
  speechText,
  confirmLabel = 'Sim',
  cancelLabel = 'Não',
  onConfirm,
  onDismiss,
}: ConfirmDialogProps) {
  const { colors } = useAppTheme();

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onDismiss}>
      <View style={{
        flex: 1,
        backgroundColor: colors.overlay,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 24,
      }}>
        <View style={{
          backgroundColor: colors.dialogBackground,
          borderRadius: 20,
          padding: 32,
          alignItems: 'center',
          width: '100%',
          maxWidth: 400,
        }}>
          <MaterialCommunityIcons name={icon as any} size={80} color={iconColor} />
          <Text variant="headlineSmall" style={{
            fontWeight: '700',
            marginTop: 16,
            textAlign: 'center',
            color: colors.text,
          }}>
            {title}
          </Text>
          <Text variant="bodyLarge" style={{
            color: colors.textSecondary,
            marginTop: 8,
            marginBottom: 24,
            textAlign: 'center',
          }}>
            {message}
          </Text>
          <View style={{
            flexDirection: 'row',
            gap: 16,
            width: '100%',
          }}>
            <Pressable
              style={{
                flex: 1,
                backgroundColor: colors.success,
                paddingVertical: 18,
                borderRadius: 12,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
              }}
              onPress={() => {
                Speech.speak(confirmLabel, { language: 'pt-BR', pitch: 1.2 });
                onConfirm();
              }}
            >
              <MaterialCommunityIcons name="check" size={28} color="#ffffff" />
              <Text variant="titleLarge" style={{ color: '#ffffff', fontWeight: '700' }}>{confirmLabel}</Text>
            </Pressable>
            <Pressable
              style={{
                flex: 1,
                backgroundColor: colors.danger,
                paddingVertical: 18,
                borderRadius: 12,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
              }}
              onPress={onDismiss}
            >
              <MaterialCommunityIcons name="close" size={28} color="#ffffff" />
              <Text variant="titleLarge" style={{ color: '#ffffff', fontWeight: '700' }}>{cancelLabel}</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

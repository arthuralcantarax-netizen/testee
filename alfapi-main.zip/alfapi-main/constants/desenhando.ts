import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export const CANVAS_SIZE = Math.min(SCREEN_WIDTH - 24, SCREEN_HEIGHT * 0.6);
export const STROKE_WIDTH = 28;
export const COVERAGE_THRESHOLD = 0.35;
export const LETTER_FONT_SIZE = CANVAS_SIZE * 0.85;
export const LETTER_OPACITY = 0.25;
export const MIN_POINTS_VALID = 15;
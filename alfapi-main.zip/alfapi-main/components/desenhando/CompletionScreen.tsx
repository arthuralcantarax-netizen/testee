import { View, Pressable } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';
import { useAppTheme } from '@/contexts/ThemeContext';

interface CompletionScreenProps {
  onBack: () => void;
  onReset: () => void;
}

export function CompletionScreen({ onBack, onReset }: CompletionScreenProps) {
  const { colors } = useAppTheme();

  return (
    <View style={{
      flex: 1,
      backgroundColor: colors.background,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 24,
    }}>
      <MaterialCommunityIcons name="trophy" size={120} color="#FFD700" />
      <Text variant="headlineLarge" style={{
        fontWeight: '700',
        color: colors.text,
        marginTop: 24,
        fontSize: 40,
      }}>
        Parabéns!
      </Text>
      <Text variant="titleLarge" style={{
        color: colors.textSecondary,
        marginTop: 8,
        marginBottom: 48,
      }}>
        Você completou o alfabeto!
      </Text>

      <View style={{
        flexDirection: 'row',
        gap: 20,
        flexWrap: 'wrap',
        justifyContent: 'center',
      }}>
        <Pressable
          style={{
            backgroundColor: colors.primary,
            paddingVertical: 20,
            paddingHorizontal: 32,
            borderRadius: 16,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 12,
            minWidth: 200,
            justifyContent: 'center',
          }}
          onPress={() => {
            Speech.speak('Voltar ao menu', { language: 'pt-BR', pitch: 1.2 });
            onBack();
          }}
        >
          <MaterialCommunityIcons name="home" size={32} color="#ffffff" />
          <Text variant="headlineSmall" style={{ color: '#ffffff', fontWeight: '700' }}>Voltar ao Menu</Text>
        </Pressable>

        <Pressable
          style={{
            backgroundColor: colors.danger,
            paddingVertical: 20,
            paddingHorizontal: 32,
            borderRadius: 16,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 12,
            minWidth: 200,
            justifyContent: 'center',
          }}
          onPress={() => {
            Speech.speak('Resetar progresso', { language: 'pt-BR', pitch: 1.2 });
            onReset();
          }}
        >
          <MaterialCommunityIcons name="restart" size={32} color="#ffffff" />
          <Text variant="headlineSmall" style={{ color: '#ffffff', fontWeight: '700' }}>Resetar Progresso</Text>
        </Pressable>
      </View>
    </View>
  );
}

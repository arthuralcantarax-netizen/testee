# Alfapi

Aplicativo mobile de alfabetização digital desenvolvido com **Expo**, **React Native** e **TypeScript**. O Alfapi oferece módulos interativos para aprendizado do alfabeto português, com foco em acessibilidade e inclusão.

## Funcionalidades

### Tela de Login
- Autenticação por email/senha
- Integração com GOV.BR (placeholder)
- Recuperação de conta

### Aprenda Desenhando
- Canvas interativo com **Skia** para desenhar letras com o dedo
- Marca d'água da letra como guia visual
- Verificação automática do traçado com análise de cobertura espacial
- Progresso salvo localmente por letra (maiúscula e minúscula)
- Feedback por voz com **expo-speech**
- Tela de conclusão ao completar o alfabeto

### Aprenda Escutando
- Quiz com 20 perguntas sobre identificação de letras
- 4 opções por pergunta, embaralhadas aleatoriamente
- Feedback visual (verde/vermelho) e por voz
- Tela de resultado com pontuação e mensagens motivacionais

### Cofre de Documentos
- Armazenamento seguro de documentos com **autenticação biométrica** (impressão digital/face)
- Adicionar documentos via câmera ou galeria
- Visualização e exclusão de documentos
- Arquivos salvos localmente com **expo-file-system** e **expo-sqlite**

### Painel do Aluno
- Painel centralizado com acesso rápido às informações do aluno
- Visualização detalhada de dados e progresso acadêmico
- Interface intuitiva para gestão de documentos e tarefas

### Acessibilidade
- Seletor de temas com 5 opções de acessibilidade visual:
  - **Padrão** — tema padrão do sistema
  - **Alto Contraste** — máximo contraste para visão reduzida
  - **Escuro** — fundo escuro para conforto visual
  - **Deuteranopia** — adaptado para daltonismo verde-vermelho
  - **Protanopia** — adaptado para daltonismo vermelho-verde
- Todas as telas possuem feedback por voz (TTS)

## Tecnologias

| Tecnologia | Versão | Uso |
|---|---|---|
| Expo SDK | 54 | Framework principal |
| React Native | 0.81.5 | Runtime mobile |
| React | 19.1 | UI |
| TypeScript | 5.9 | Tipagem estática |
| expo-router | 6 | Navegação (file-based routing) |
| expo-sqlite | 16 | Banco de dados local |
| @shopify/react-native-skia | 2.2 | Canvas de desenho |
| react-native-paper | 5 | Componentes Material Design 3 |
| expo-speech | 14 | Text-to-Speech |
| expo-local-authentication | 17 | Autenticação biométrica |
| expo-image-picker | 17 | Câmera e galeria |
| react-native-gesture-handler | 2.28 | Gestos touch |
| react-native-reanimated | 4.1 | Animações |

## Pré-requisitos

- **Node.js** 18+
- **npm** ou **yarn**
- **Android Studio** (para build Android)
- **Java JDK** 17+
- **Android SDK** com API level adequado

## Instalação

```bash
npm install
```

## Desenvolvimento

```bash
npx expo start
```

Na saída, você terá opções para abrir o app em:

- [Development build](https://docs.expo.dev/develop/development-builds/introduction/)
- [Emulador Android](https://docs.expo.dev/workflow/android-studio-emulator/)
- [Simulador iOS](https://docs.expo.dev/workflow/ios-simulator/)
- [Expo Go](https://expo.dev/go)

## Build Android

### Gerar APK de Debug

```bash
cd android && ./gradlew assembleDebug
```

O arquivo será gerado em `android/app/build/outputs/apk/debug/app-debug.apk`

### Gerar APK de Release

```bash
cd android && ./gradlew assembleRelease
```

O arquivo será gerado em `android/app/build/outputs/apk/release/app-release.apk`

### Gerar AAB (Android App Bundle)

```bash
cd android && ./gradlew bundleRelease
```

O arquivo será gerado em `android/app/build/outputs/bundle/release/app-release.aab`

### Limpar Build

```bash
cd android && ./gradlew clean
```

### Build Completo (Clean + Release)

```bash
cd android && ./gradlew clean && ./gradlew assembleRelease
```

> **Nota:** O build de release atualmente utiliza a keystore de debug. Para produção, gere uma keystore própria e configure o `signingConfigs` em `android/app/build.gradle`. Veja a [documentação oficial](https://reactnative.dev/docs/signed-apk-android).

## Estrutura do Projeto

```
alfapi/
├── app/                          # Telas (expo-router file-based routing)
│   ├── _layout.tsx               # Layout raiz com providers
│   ├── index.tsx                 # Tela de login
│   ├── menu.tsx                  # Menu principal
│   ├── aprenda-desenhando.tsx    # Módulo de desenho de letras
│   ├── aprenda-falando.tsx       # Módulo de quiz auditivo
│   ├── cofre-documentos.tsx      # Cofre de documentos com biometria
│   ├── acessibilidade.tsx        # Configuração de temas acessíveis
│   └── painel-aluno.tsx          # Módulo do painel do aluno
├── components/                   # Componentes reutilizáveis
│   ├── desenhando/               # Componentes do módulo de desenho
│   │   ├── LetterWatermark.tsx   # Marca d'água da letra no canvas
│   │   ├── DrawingControls.tsx   # Botões de controle do desenho
│   │   └── CompletionScreen.tsx  # Tela de conclusão do alfabeto
│   ├── cofre/                    # Componentes do cofre de documentos
│   │   ├── AuthScreen.tsx        # Tela de autenticação biométrica
│   │   ├── DocumentCard.tsx      # Card de documento
│   │   ├── DocumentViewerModal.tsx # Modal de visualização
│   │   ├── AddDocumentOptions.tsx  # Opções de adicionar documento
│   │   └── EmptyDocuments.tsx    # Estado vazio do cofre
│   ├── MenuButton.tsx            # Botão do menu principal
│   └── ConfirmDialog.tsx         # Diálogo de confirmação com voz
├── constants/                    # Constantes da aplicação
│   ├── themes.ts                 # Definição dos 5 temas de acessibilidade
│   ├── desenhando.ts             # Configurações do canvas de desenho
│   └── escutando.ts              # Configurações do quiz
│               
├── contexts/                     # Contextos React
│   └── ThemeContext.tsx           # Provider de tema com persistência em SQLite
├── hooks/                        # Custom hooks
│   ├── use-letter-progress.ts    # Gerenciamento de progresso das letras
│   └── use-cofre-documentos.ts   # CRUD de documentos no cofre
├── styles/                       # Stylesheets separados por tela
├── types/                        # Tipos TypeScript
│   └── index.ts                  # Point, Stroke, Document, LetterProgress, QuizQuestion
├── utils/                        # Funções utilitárias
│   ├── drawing.ts                # Lógica de verificação de desenho
│   └── quiz.ts                   # Geração de quiz aleatório
├── plugins/                      # Plugins do Expo
│   └── withLocalProperties.js    # Auto-configuração do SDK Android
├── assets/images/                # Imagens e ícones
├── android/                      # Projeto nativo Android
├── app.json                      # Configuração do Expo
├── package.json                  # Dependências e scripts
└── tsconfig.json                 # Configuração do TypeScript
```

## Banco de Dados (SQLite)

O app utiliza o **expo-sqlite** com 3 tabelas:

| Tabela | Descrição |
|---|---|
| `letter_progress` | Progresso de cada letra do alfabeto (52 registros: A-Z maiúsculas e minúsculas) |
| `documents` | Documentos salvos no cofre com filename e data |
| `settings` | Configurações do app (tema selecionado) |

## Scripts Disponíveis

| Comando | Descrição |
|---|---|
| `npm start` | Inicia o servidor de desenvolvimento Expo |
| `npm run android` | Executa no emulador/dispositivo Android |
| `npm run ios` | Executa no simulador/dispositivo iOS |
| `npm run web` | Inicia no navegador |
| `npm run lint` | Executa o ESLint |

## Configuração Android

- **Package:** `com.alfapi`
- **New Architecture:** habilitada
- **Hermes Engine:** habilitado
- **Edge-to-edge:** habilitado
- **Arquiteturas:** armeabi-v7a, arm64-v8a, x86, x86_64

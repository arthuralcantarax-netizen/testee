export interface Point {
  x: number;
  y: number;
}

export interface Stroke {
  id: string;
  points: Point[];
}

export interface Document {
  id: number;
  filename: string;
  original_name: string;
  created_at: string;
}

export interface LetterProgress {
  id: number;
  letter: string;
  attempts: number;
  best_score: number;
  mastered: number;
  last_practiced_at: string;
}

export interface QuizQuestion {
  correctLetter: string;
  options: string[];
}

export interface QuizResult {
  id: number;
  score: number;
  total_questions: number;
  date_taken: string;
}